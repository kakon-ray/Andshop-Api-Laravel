
## Jwt multi authentication completed
 Email Login
 Google and Facebook Login
 Password Reset and Forget password
 Email Verification

 ## Laravel Api generate with jwt authentication 

## Job Task Scheduling using email verification expired token
# https://www.youtube.com/watch?v=HL88M86qtIk&t=653s

php artisan make:command Test

## Running The Scheduler Locally
php artisan schedule:work
php artisan schedule:run